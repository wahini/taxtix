/* ./src/components/Header/Header.js */
import React from 'react';
import './Header.css';

const Header = ({ handleRefresh }) => (
  <header className="top-header">
    {/* <button className="refresh-button" onClick={handleRefresh}>Refresh</button> */}
  </header>
);

export default Header;